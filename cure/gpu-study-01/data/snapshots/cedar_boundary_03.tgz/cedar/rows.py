def select_rows(rows, count=None):
    if not count:
        return rows
    if count < 0:
        raise ValueError('negative count')
    return rows[:count]
