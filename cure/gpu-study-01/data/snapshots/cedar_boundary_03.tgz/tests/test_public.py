from cedar.rows import select_rows
def test_positive():
    assert select_rows(['a','b','c'], 2) == ['a','b']
