class LocalTransport:
    def send(self, item):
        return 'local:' + item

class ParcelClient:
    def __init__(self, transport=LocalTransport()):
        self.transport = transport
    def dispatch(self, item):
        return self.transport.send(item)
