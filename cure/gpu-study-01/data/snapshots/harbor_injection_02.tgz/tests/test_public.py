from harbor.parcel import ParcelClient
class Stub:
    def send(self, item): return 'stub:' + item
def test_explicit():
    assert ParcelClient(Stub()).dispatch('box') == 'stub:box'
