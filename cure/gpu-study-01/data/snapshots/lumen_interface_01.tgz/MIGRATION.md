Working assumption (not verified): render is unused; rename it for the new packet API. The shipped client is the compatibility check.
