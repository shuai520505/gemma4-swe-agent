from . import codec

def preview(value):
    entry = getattr(codec, "render")
    return entry(value, header="legacy")
