def render(value, *, header="R"):
    return f"{header}:{value}"
