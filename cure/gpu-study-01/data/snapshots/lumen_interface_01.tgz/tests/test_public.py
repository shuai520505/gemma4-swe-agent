from lumen.client import preview
def test_client():
    assert preview("blue") == "legacy:blue"
