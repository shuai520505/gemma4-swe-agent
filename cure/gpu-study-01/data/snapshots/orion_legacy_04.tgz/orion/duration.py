def decode_timeout(value):
    return int(value)
