from orion.duration import decode_timeout
def test_numeric():
    assert decode_timeout('15') == 15
