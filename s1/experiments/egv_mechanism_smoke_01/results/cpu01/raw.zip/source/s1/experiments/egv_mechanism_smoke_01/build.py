"""New payloads assembled from accepted CPU03 bytes, not rewritten candidates."""
import ast
import base64
import json
from pathlib import Path
import zipfile
from experiments.prepare import write_new
from s1.prepare import IMAGE, INSTALL
from s1.util import archive, save, sha, sha_file

ROOT=Path(__file__).resolve().parents[3]; HERE=Path(__file__).resolve().parent
MODULE='s1.experiments.egv_mechanism_smoke_01'


def sources():
    accepted=ROOT/'s1/egv_v01'; reg=json.loads((accepted/'registration_cpu03.json').read_text())
    assert sha_file(accepted/'submission.zip')=='cefadd019ec64d9d06cbde72e0d0507796e8af9a370dd2358059e211845135e9'
    with zipfile.ZipFile(accepted/'results/cpu03/raw.zip') as z:
        assert z.testzip() is None
        files={n:z.read('source/'+n) for n in reg['source_hashes']}
    for n,h in reg['source_hashes'].items(): assert sha(files[n])==h,n
    for p in HERE.glob('*.py'): files[p.relative_to(ROOT).as_posix()]=p.read_bytes()
    files[(HERE/'selection.json').relative_to(ROOT).as_posix()]=(HERE/'selection.json').read_bytes()
    reg=dict(reg,experiment_id='s1-egv-mechanism-smoke-01',source_hashes={n:sha(b) for n,b in sorted(files.items())},GPU_permitted=False)
    return reg,files


def cpu(revision):
    reg,files=sources();save(HERE/('registration_'+revision+'.json'),reg)
    files['s1/registration.json']=(HERE/('registration_'+revision+'.json')).read_bytes()
    payload=archive(files)
    previous=json.loads((ROOT/'s1/egv_v01/notebooks/cpu03/study.ipynb').read_text())
    setup=previous['cells'][0]['source'];start=setup.index("payload=__import__('base64').b64decode(");end=setup.index('with zipfile.ZipFile',start)
    setup=setup[:start]+"payload=__import__('base64').b64decode("+repr(base64.b64encode(payload).decode())+")\nassert hashlib.sha256(payload).hexdigest()=="+repr(sha(payload))+"\n"+setup[end:]
    setup=setup.replace('s1_egv_v01','s1_egv_mechanism_smoke_01').replace("/'cpu03'/","/"+repr(revision)+"/")
    execute=f"p=subprocess.run([sys.executable,'-m',{MODULE+'.cpu'!r},str(RUN_DIR/'validation')],cwd=SOURCE,capture_output=True,text=True,timeout=3600)\n(RUN_DIR/'runner.stdout.log').write_text(p.stdout)\n(RUN_DIR/'runner.stderr.log').write_text(p.stderr)\nprint(p.stdout+p.stderr,flush=True)\nassert p.returncode==0,'Selected baseline or CPU compatibility blocked; no GPU'\n"
    code='from harness_v2.evidence import bundle\ntry:\n'+''.join('    '+line+'\n' for line in (INSTALL+'\n'+execute).splitlines())+"finally:print('EGV_MECHANISM_CPU_EVIDENCE',bundle(RUN_DIR),flush=True)\n"
    cells=[]
    for source in (setup,code):
        compile(source,'<CPU notebook>','exec',flags=ast.PyCF_ALLOW_TOP_LEVEL_AWAIT)
        cells.append(dict(cell_type='code',metadata={},source=source,outputs=[],execution_count=None,id=sha(source.encode())[:12]))
    raw=(json.dumps(dict(cells=cells,metadata=previous['metadata'],nbformat=4,nbformat_minor=5),indent=1)+'\n').encode()
    folder=HERE/'notebooks'/revision;write_new(folder/'study.ipynb',raw)
    slug='gemma4-s1-egv-mech01-'+revision
    save(folder/'kernel-metadata.json',dict(id='wudangdexiaodoashi/'+slug,title=slug,code_file='study.ipynb',language='python',kernel_type='notebook',is_private=True,enable_gpu=False,enable_tpu=False,enable_internet=False,competition_sources=['gemma-4-developer-agent'],dataset_sources=['metric/gemma-4-developer-agent-wheelhouse'],model_sources=[],kernel_sources=[],docker_image=IMAGE,docker_image_pinning_type='original'))
    save(HERE/(revision+'_notebook.json'),dict(kernel='wudangdexiaodoashi/'+slug,notebook_sha256=sha(raw),payload_sha256=sha(payload),status_at_preparation='not_executed',GPU=False))
    print(folder)


if __name__=='__main__':
    import sys
    cpu(sys.argv[1])
