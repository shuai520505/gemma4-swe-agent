"""CPU-only infrastructure regressions."""
