accepts(n) is True exactly when n >= 0. Preserve negative rejection.
