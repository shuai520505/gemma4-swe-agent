import app, pathlib, hashlib, sys
p=pathlib.Path(app.__file__).resolve()
assert p==pathlib.Path('app.py').resolve(), (p,sys.path)
print('SOURCE',str(p),hashlib.sha256(p.read_bytes()).hexdigest(),flush=True)
assert app.accepts(0) is True, 'TARGET_ZERO'
assert app.accepts(3) is True, 'TARGET_POSITIVE'
assert app.accepts(-1) is False, 'OLD_NEGATIVE'
print('TARGET_AND_OLD_PASSED',flush=True)
