"""Minimal task/environment adaptation of the CPU- and GPU-proven GPU03 Session.

The official Runner, worker, tools, verifier and chroot implementation are reused
byte-for-byte. CPU transport is supplied externally, never in the production ZIP.
This preparation has no matching GPU authorization, so GPU entry fails closed.
"""
import inspect,json,time,types
from pathlib import Path
from ..runtime import install_extras,fingerprint
from ..dependencies import HERE as STUDY,ROOT,sha

HERE=Path(__file__).resolve().parent

def adapted_session():
    from u_re.v01.experiments.action_priority_01.real_gemma_abba03 import session as proven
    lock=json.loads((HERE/'ABBA_EXPERIMENT_LOCK.json').read_bytes())
    ids=[t['instance_id'] for t in lock['tasks']]
    code=inspect.getsource(proven.run)
    substitutions={
        "lock=json.loads((PRIOR/'ABBA_EXPERIMENT_LOCK.json').read_bytes())":"lock=json.loads((HERE/'ABBA_EXPERIMENT_LOCK.json').read_bytes())",
        "assert grant['GPU_authorized'] and grant['max_SaveKernel_dispatches']==1 and grant['max_Agent_runs']==4":"assert mode=='CPU_DRY_RUN' and not grant['GPU_authorized'], 'New matching V02b GPU authorization and batch binding required'",
        "assert grant['order']==lock['order'] and grant['Agent_seconds']==300 and grant['platform_window_seconds']==10000":"assert grant['order']==lock['order'] and grant['Agent_seconds']==300 and grant['platform_window_seconds']==10000",
        "EVIDENCE_RECONCILED_TWO_TASKS_ADMITTED":"EVIDENCE_RECONCILED_FOUR_TASKS_ADMITTED",
        "['fastapi_9425','fastapi_14786']":repr(ids),
        "GPU03_PAYLOAD_END_TO_END_CPU_PASS":"V02B_PAYLOAD_END_TO_END_CPU_PASS",
    }
    for old,new in substitutions.items():
        assert old in code,('GPU03 adaptation anchor drift',old)
        code=code.replace(old,new)
    namespace=dict(proven.__dict__,HERE=HERE,ROOT=ROOT,__name__=__name__)
    exec(compile(code,'<V02b-minimal-GPU03-session-adaptation>','exec'),namespace)
    return namespace['run']

async def run(output,session_started,*,mode='GPU',cpu_transport=None,quota_at_dispatch=None):
    # This guard precedes dependency installs, model allocation and inference.
    assert mode=='CPU_DRY_RUN' and cpu_transport is not None,'GPU NOT_AUTHORIZED for the new V02b environment/cohort'
    from harness_v2.evidence import atomic_json
    lock=json.loads((STUDY/'V02B_ENVIRONMENT_LOCK.json').read_bytes())
    actual=install_extras(Path(output).parent/'environment')
    assert actual==lock['fingerprint'],'Production environment differs from screened environment'
    atomic_json(Path(output).parent/'PRODUCTION_ENVIRONMENT_BEFORE.json',actual)
    await adapted_session()(output,session_started,mode=mode,cpu_transport=cpu_transport,quota_at_dispatch=quota_at_dispatch)
    assert fingerprint()==actual,'Production run changed frozen trusted dependency environment'
    atomic_json(Path(output).parent/'PRODUCTION_ENVIRONMENT_AFTER.json',fingerprint())
